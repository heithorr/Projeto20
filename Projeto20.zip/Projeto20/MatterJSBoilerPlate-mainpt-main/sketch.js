
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Body = Matter.Body;

var ground;
var world, engine;
var bola, quadrado, retangulo;



function preload()
{
	
}

function setup() {
	createCanvas(800, 700);

	engine = Engine.create();
	world = engine.world;

	var ground_options = {
		isStatic : true 
	}

	var bola_options = {
		restitution : 0.95,
		frictionAir : 0.01
	}

    ground = Bodies.rectangle(200,390,400,20,ground_options);
	World.add(world,ground);
    
	bola = Bodies.circle(100,10,20,bola_options);
    World.add(world,bola);







	Engine.run(engine);
  
}


function draw() {
  rectMode(CENTER);
  background(50,205,50);

  Engine.update(engine);

  rect(ground.position.x,ground.position.y,400,20);
  ellipse(bola.position.x,bola.position.y,20);

  drawSprites();
 
}



